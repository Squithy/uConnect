precision mediump float;

uniform vec4 Ucolor;

void main() 
{
	gl_FragColor = Ucolor;
}
