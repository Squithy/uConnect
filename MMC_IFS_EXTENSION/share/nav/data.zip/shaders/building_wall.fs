precision mediump float;

uniform vec4 Ucolor;
varying vec4 v_color;

void main() 
{
	/*gl_FragColor = Ucolor * 0.5;
	gl_FragColor.a = 1.; */
	
	gl_FragColor = v_color;
}
