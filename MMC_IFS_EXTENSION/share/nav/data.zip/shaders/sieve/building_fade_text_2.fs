precision mediump float;

varying vec2 v_txCoor;
uniform sampler2D texture;

void main()
{
	
	vec4 c = texture2D( texture, v_txCoor );
	gl_FragColor.rgb = c.rgb;
	gl_FragColor.a = c.a;

	if( floor(mod(gl_FragCoord.x, 2.)) < 0.9 &&
	    floor(mod(gl_FragCoord.y+1., 2.)) < 0.9 )
		gl_FragColor.a = 0.;
}
