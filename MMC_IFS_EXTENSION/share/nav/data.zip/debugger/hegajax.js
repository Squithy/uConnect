
var eventSource = (navigator.appName.indexOf('Opera') == -1) ? window : document; // I use this because I might want to make it cross browser later
var loc = eventSource.location.href; // the current page href
var server = loc.match(/^[^\/]*\/\/[^\/]*\//);

function isEmpty(obj) {
	for (var p in obj) {
		if( obj.hasOwnProperty(p) )
			return false;
	}
	return true;
}

if ( String.prototype.trim == null ) {
	String.prototype.trim = function() { return this.replace(/^\s+|\s+$/g,""); }
}

///////////////////////////////////////
// Cookie stuff
///////////////////////////////////////

var _cookieCache = {};

function setCookie(name, value, expiredays)
{
	_cookieCache[name] = value;
	if ( typeof expiredays  == "undefined" ) {
		expiredays = 5000;
	}
	var expires;
	if( expiredays > 0 ) {
		var exdate = new Date();
		exdate.setDate(exdate.getDate()+expiredays);
		var expires = "; expires=" + exdate.toGMTString();
	}
	else expires = "";
	document.cookie = name+ "=" + encodeURIComponent(value) + expires;	
}

function getCookie(name, defVal)
{
	if ( name in _cookieCache ) {
		return _cookieCache[name] == null ? defVal : _cookieCache[name];
	}
	var cookies = document.cookie.replace(/\s/g,"").split(';');
	var nameEQ = name + "=";
	for ( var i = 0; i < cookies.length; ++i ) {
		var c = cookies[i];
		if ( !c.indexOf(nameEQ) ) return (_cookieCache[name] = decodeURIComponent(c.substring(nameEQ.length)));
	}
	_cookieCache[name] = null;
	return defVal;
}
 
function hasCookie(name)
{
	if ( name in _cookieCache )
		return _cookieCache[name] != null;
	var cookies = document.cookie.replace(/\s/g,"").split(';');
	var nameEQ = name + "=";
	for ( var i = 0; i < cookies.length; ++i ) {
		var c = cookies[i];
		if ( !c.indexOf(nameEQ) ) return true;
	}
	return false;
}
 
////////////////////////////////////
// AJAX stuff
////////////////////////////////////

// function loadXMLDoc(url, stateChangeFunc, failfunc, method, data, timeout)
// {
// 	var xmlhttp=null;
// 	if (window.XMLHttpRequest)
// 	{// code for Firefox, Opera, IE7, etc.
// 		xmlhttp=new XMLHttpRequest();
// 	}
// 	else if (window.ActiveXObject)
// 	{// code for IE6, IE5
// 		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
// 	}
// 	if (xmlhttp!=null)
// 	{
// 		xmlhttp.onreadystatechange = function(e) { if ( stateChangeFunc ) stateChangeFunc(); };
// 		xmlhttp.open(method || "GET", server+url, true);
// 		xmlhttp.send(data);
// 		xmlhttp.requestSentAt = (new Date).getTime();
// 	}
// 	else
// 	{
// 		alert("Your browser does not support XMLHTTP.");
// 	}
// 	return xmlhttp;
// }

function SmartXMLHttpRequest(url, stateChangeFunc, failfunc, timeout)
{
	var defRequestTimeout = (+getCookie("def_request_timeout", 3000));

	var xmlhttp = null;
	var failFunc = failfunc;
	var pendingRequests = {}; // have to keep track of them to protect them from the garbage collector
	var id = 0;

	var _RenewXmlHttpObj = function()
	{
		xmlhttp=null;
		if (window.XMLHttpRequest)
		{// code for Firefox, Opera, IE7, etc.
			xmlhttp=new XMLHttpRequest();
		}
		else if (window.ActiveXObject)
		{// code for IE6, IE5
			xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
		}
		else
		{
			alert("Your browser does not support XMLHTTP.");
			return false;
		}
		xmlhttp.reqid = id++;
		return true;
	}
	var _StateChange = function()
	{
		if ( this.readyState == 4 ) {
			//console.log("clearTimeout: " + this.timeout_id);
			self.clearTimeout(this.timeout_id);
			this.keepmealive = null;
			delete pendingRequests[this.reqid];
		}
		if ( stateChangeFunc )
			stateChangeFunc(this);
	}	
	var _RequestTimeout = function(reqid)
	{
		var thatxmlhttp = pendingRequests[reqid];
		//console.log("_RequestTimeout("+reqid+")");
		if ( thatxmlhttp ) {
			thatxmlhttp.abort();
			thatxmlhttp.keepmealive = null;
			delete pendingRequests[reqid];
			//console.log("request timeout: " + thatxmlhttp.timeout_id);
		}
		if ( failFunc )
			failFunc(xmlhttp, 503);
	}

	this.Send = function(method, data)
	{
		xmlhttp = null;
		if ( _RenewXmlHttpObj() )
		{
			pendingRequests[xmlhttp.reqid] = xmlhttp;
			xmlhttp.onreadystatechange = _StateChange;
			xmlhttp.open(method || "GET", server+url, true);
			xmlhttp.send(data);	
			xmlhttp.requestSentAt = (new Date).getTime();
			var rid = xmlhttp.reqid; // dirty-dirty hack to induce passing parameter by value instead of reference in next line
			xmlhttp.timeout_id = self.setTimeout(function() { _RequestTimeout(rid) }, timeout || defRequestTimeout);
			xmlhttp.keepmealive = this; // oh mighty XmlHttpRequest, please protect me from the evil garbage collector until you're finished with your job (in case if the even more evil caller might forget or unable to keep my reference)!
			//console.log("setTimeout: " + xmlhttp.timeout_id);			
		}
		return xmlhttp;
	}
	this.GetLastXmlHttpRequest = function() {
		return xmlhttp;
	}
	this.DropPendingRequests = function() {
		for ( var reqid in pendingRequests ) {
			pendingRequests[reqid].abort();
			delete pendingRequests[reqid];
		}
	}
}

function simpleLoadXMLDoc(url, readyfunc, failfunc, method, data, timeout)
{
	function _myStatechangeFunc(xmlhttp) {
		if ( xmlhttp && xmlhttp.readyState==4 && xmlhttp.status==200 ) {
			readyfunc(xmlhttp.responseXML);
		}
	}
	(new SmartXMLHttpRequest(url, readyfunc ? _myStatechangeFunc : null, failfunc, timeout)).Send(method, data);
}

function SpeedThrottle(url, pollInterval, funcSucc, funcFail, allowParallelPolling)
{
	var maxParallelPolls = allowParallelPolling ? (+getCookie("max_parallel_polls", 10)) : 1;
	var stopOnRequestTimeout = !!(+getCookie("stop_throttle_on_timeout", true));

	var url = url;
	var pollInterval = pollInterval;
	var timerId;
	var parallelPolls = 0;

	var _Callback_statechange = function(xmlhttp) {
		if ( xmlhttp && xmlhttp.readyState==4 && xmlhttp.status ) {
			if ( xmlhttp.status!=200 ) {
				_Callback_fail(xmlhttp, xmlhttp.status);
			} else {
				--parallelPolls;
				if ( funcSucc )
					funcSucc(xmlhttp);
			}
		}
	};
	var _Callback_fail = function(xmlhttp, errcode) {
		if ( errcode != 503 || stopOnRequestTimeout )
			_StopPolling();
		else
			--parallelPolls;
		if ( funcFail )
			funcFail(xmlhttp, errcode);
	};
	var _DoParallelPoll = function() {
		if ( parallelPolls >= maxParallelPolls ) {
			_StopPolling();
			alert("poll overflow");
			funcFail(xmlhttp, 503);
		} else {
			parallelPolls++;
			sxhr.Send();
		}
	}
	var _DoSinglePoll = function() {
		if ( !parallelPolls ) {
			++parallelPolls;
			sxhr.Send();
		}	
	}
	var _DoPoll = allowParallelPolling ? _DoParallelPoll : _DoSinglePoll;
	var _StopPolling = function(dropReqs) {
		if ( !timerId ) return;
		self.clearInterval(timerId);
		timerId = null;
		if ( dropReqs ) sxhr.DropPendingRequests();
		parallelPolls = 0;
	};
	var sxhr = new SmartXMLHttpRequest(url, _Callback_statechange, _Callback_fail);
	
	this.Start  = function() {
		if ( timerId ) return;
		parallelPolls = 0;
		timerId = self.setInterval(_DoPoll, pollInterval);
	};
	this.Stop = _StopPolling;
	this.IsRunning = function() {
		return !!timerId;
	};
	this.GetPollInterval = function() {
		pollInterval;
	}
	this.SetPollInterval = function(interval) {
		if ( !timerId ) return; // don't restart automatically
		self.clearInterval(timerId);
		pollInterval = interval;
		timerId = self.setInterval(_DoPoll, pollInterval);
	}
}

//////////////////////////////////////////////////////////////
// Remote debugger specific
//////////////////////////////////////////////////////////////

function DebugPoller()
{
	var services = {};
	var poller = null;
	
	var rsptimes = [];
	var updtimes = [];
	var maxtimes = [];
	var timewndlen = (+getCookie("dbgpoll_timewnd_length", 10));
	var timewndidx = 0;
	var pollspeed = (+getCookie("dbgpoll_start_pollspeed", 300));
	var minPollInterval = (+getCookie("dbgpoll_min_pollspeed", 100)); // max 10 polls per sec
	var maxPollInterval = (+getCookie("dbgpoll_max_pollspeed", 3000));
	var alfa = (+getCookie("dbgpoll_alfa", 0.3)); // adaptivity coeff.
	var chgSensitivity = (+getCookie("dbgpoll_chgsens", 0.1)); // at least 10% diff
	var allowParallelPolling = !!(+getCookie("dbgpoll_parallel_polling", false));
	
	var _UpdatePoll = function() {
		if ( poller ) poller.Stop(false);
		if ( !isEmpty(services) ) {
			var serviceNames = [];
			for ( var key in services ) {
				serviceNames.push(key);
			}
			poller = new SpeedThrottle('debug-polling/'+serviceNames.join(','), pollspeed, _StatusChanged, _PollFailed, allowParallelPolling);
			poller.Start();			
			if ( infobox ) document.getElementById("infobox_pollspeed").innerHTML = Math.round(pollspeed);
		}
	}
	var _UpdateThrottleTimer = function() {
		var avg = 0;
		for ( var i=0; i<timewndlen; avg += maxtimes[i++] );
		avg /= timewndlen;
		var newspd = Math.min(Math.max(pollspeed + alfa*(avg-pollspeed), minPollInterval), maxPollInterval);
		if ( Math.abs(newspd - pollspeed) > pollspeed*chgSensitivity ) {
			pollspeed = newspd;
			poller.SetPollInterval(pollspeed);
		}
		if ( infobox ) document.getElementById("infobox_pollspeed").innerHTML = Math.round(pollspeed);
	}
	var _StatusChanged = function(xmlhttp) {
		if ( xmlhttp && xmlhttp.readyState==4 )
		{// 4 = "loaded"
			if ( xmlhttp.status==200 )
			{// 200 = "OK"
				rsptimes[timewndidx] = (new Date).getTime() - xmlhttp.requestSentAt;
				var updateStartTime = (new Date).getTime();				
				var responses = xmlhttp.responseXML.getElementsByTagName("responses")[0];
				for (var i=0; i < responses.childNodes.length; ++i) {
					var node = responses.childNodes[i];
					if ( node.nodeName in services )
						services[node.nodeName].UpdateFunc(node);
				}
				updtimes[timewndidx] = (new Date).getTime() - updateStartTime;
				maxtimes[timewndidx] = rsptimes[timewndidx] > updtimes[timewndidx] ? rsptimes[timewndidx] : updtimes[timewndidx];

				if ( infobox ) {
					document.getElementById("infobox_responsetime").innerHTML = rsptimes[timewndidx];
					document.getElementById("infobox_updatetime").innerHTML = updtimes[timewndidx];
				}

				if ( ++timewndidx == timewndlen ) {
					_UpdateThrottleTimer();
					timewndidx = 0;
				}
			}
			else
			{
				for (var name in services) {
					if ( services[name].PollFailedFunc ) services[name].PollFailedFunc(xmlhttp, xmlhttp.status);
				}
			}
			if ( infobox ) document.getElementById("infobox_connstate").innerHTML = xmlhttp.status;
		}
	}
	var _PollFailed = function(xmlhttp, errcode) {
		for (var name in services) {
			if ( services[name].PollFailedFunc ) services[name].PollFailedFunc(xmlhttp, errcode);
		}
		if ( infobox && !poller.IsRunning() ) document.getElementById("infobox_connstate").innerHTML = "Connection lost";
	}
	
	this.RegisterService = function(name, UpdateFunc, PollFailedFunc) {
		if ( name && name.length && UpdateFunc ) {
			var isnew = !(name in services);
			services[name] = {
				'UpdateFunc': UpdateFunc,
				'PollFailedFunc': PollFailedFunc
			};
			if ( isnew ) _UpdatePoll();
			return true;
		} else {
			return false;
		}
	}
	this.UnregisterService = function(name) {
		delete services[name];
		_UpdatePoll();
	}
	this.Reset = function() {
		if ( poller ) poller.Stop(true);
		poller = null;
		services = {};
	}
	this.Pause = function() {
		if ( poller ) poller.Stop(true);
		if ( infobox ) document.getElementById("infobox_connstate").innerHTML = "-";
	}
	this.Start = function() {
		if ( poller ) poller.Start();
	}
	this.IsRunning = function() {
		return poller ? poller.IsRunning() : false;
	}
}
var mainPoller = new DebugPoller();

//////////////////////////////////////////////
// Tab view
//////////////////////////////////////////////

var TabbedViewStore = {};
function TabbedView(parentNode, id, onTabActivated, onTabDeactivated, width, height)
{
	this.OnTabActivated = onTabActivated;
	this.OnTabDeactivated = onTabDeactivated;
	
	var nTabs = 0;
	var actTab = -1;
	var id = id;
	
	var td, tr, t = document.createElement("TABLE");

	tr = document.createElement("TR");
	td = document.createElement("TD");
	td.setAttribute("class", "plain");
	td.innerHTML = "<table><tr id='"+id+"_tabs'></tr></table>";
	tr.appendChild(td);
	t.appendChild(tr);

	tr = document.createElement("TR");
	td = document.createElement("TD");
	td.id = id+"_view";
	td.setAttribute("class", "activetab");
	td.style.padding = "10px";
	td.style.verticalAlign = "top";
	if ( width ) td.style.width = width;
	td.style.height = height || "400px";
	td.innerHTML = "";
	tr.appendChild(td);
	t.appendChild(tr);

	parentNode.appendChild(t);
	var tabs = document.getElementById(id+"_tabs");
	TabbedViewStore[id] = this;
	
	var _AddTab = function()
	{
		var newtab = document.createElement("TD");
		newtab.setAttribute("class", "inactivetab tabtext")
		newtab.setAttribute("onclick", "TabbedViewStore['"+id+"'].ActivateTab("+nTabs+")");
		newtab.setAttribute("width", "100px");
		tabs.appendChild(newtab);
		var placeholder = document.createElement("TD");
		placeholder.style.width = "10px";
		tabs.appendChild(placeholder);		
		++nTabs;
		return newtab;
	}	
	this.AddTab = function()
	{
		if ( !nTabs ) {
			var placeholder = document.createElement("TD");
			placeholder.style.width = "10px";
			tabs.appendChild(placeholder);			
		}
		return _AddTab();
	}
	this.ActivateTab = function(idx)
	{
		if ( idx == actTab )
			return;
		if ( actTab !== -1 ) tabs.childNodes[actTab*2+1].setAttribute("class", "inactivetab tabtext");
		if ( this.OnTabDeactivated ) this.OnTabDeactivated(actTab);
		actTab = idx;
		if ( actTab !== -1 ) tabs.childNodes[actTab*2+1].setAttribute("class", "activetab tabtext");
		if ( this.OnTabActivated ) this.OnTabActivated(actTab);
	}
}

//////////////////////////////////////////////
// Info box
//////////////////////////////////////////////

var infobox;
function infoboxDisconnect()
{
	mainPoller.Pause();
	document.getElementById("infobox_disconnect").style.display = "none";
	document.getElementById("infobox_reconnect").style.display = "inline";
}
function infoboxReconnect()
{
	mainPoller.Start();
	document.getElementById("infobox_disconnect").style.display = "inline";
	document.getElementById("infobox_reconnect").style.display = "none";
}
function addInfoBox()
{
	var content = document.createElement("DIV");
	content.setAttribute("id", "iefix");
	var body = document.getElementsByTagName("BODY")[0];
	while ( body.firstChild ) {
		var node = body.firstChild;
		body.removeChild(node);
		content.appendChild(node);
	}
	body.appendChild(content);
	
	infobox = document.createElement("DIV");
	infobox.setAttribute("id", "fixme");
	infobox.innerHTML = " \
		<table class='debuginfobox'> \
			<tr><td width='120px'>Response time:</td><td><table class='plain'><tr><td id='infobox_responsetime' width='25px' align='right' class='plain'/><td class='plain' style='padding-left:3px'>ms</td></tr></table></td></tr> \
			<tr><td width='120px'>Update time:</td><td><table class='plain'><tr><td id='infobox_updatetime' width='25px' align='right' class='plain'/><td class='plain' style='padding-left:3px'>ms</td></tr></table></td></tr> \
			<tr><td width='120px'>Poll speed:</td><td><table class='plain'><tr><td id='infobox_pollspeed' width='25px' align='right' class='plain'/><td class='plain' style='padding-left:3px'>ms</td></tr></table></td></tr> \
			<tr><td width='120px'>Connection status:</td><td id='infobox_connstate' align='center' style='font-family:Monospace'>-</td></tr> \
			<tr><td colspan=2 align='center'>\
				<button id='infobox_disconnect' onclick='infoboxDisconnect()'>Disconnect</button> \
				<button id='infobox_reconnect' style='display:none' onclick='infoboxReconnect()'>Reconnect</button> \
			</td></tr> \
		</table>";
	body.appendChild(infobox);
}

// Screenshot
function initScreenshotType()
{
	var CaptureToJPEG = +getCookie("capture_to_jpeg", false);
	simpleLoadXMLDoc("debug-cmd/screenshot/image_type?" + (CaptureToJPEG ? "jpeg" : "bmp" ), null, null, "GET");
}

